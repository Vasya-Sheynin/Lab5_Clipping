
#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setWindowTitle("Clipping application");
    filePath = "";
    file = new QFile(filePath);
    updBtn = new QPushButton("Update data for segments");
    updPolyBtn = new QPushButton("Update data for polygon");
    fileBtn = new QPushButton("Select file");
    type = ClippingType::NONE;

    plot = new QCustomPlot();
    plot->addGraph();
    plot->addGraph();
    plot->setInteraction(QCP::iRangeZoom, true);
    plot->setInteraction(QCP::iRangeDrag, true);
    plot->xAxis->setRange(-10, 10);
    plot->yAxis->setRange(-10, 10);
    plot->xAxis->setLabel("X Axis");
    plot->yAxis->setLabel("Y Axis");

    plot->graph(0)->setLineStyle(QCPGraph::lsNone);
    plot->graph(1)->setLineStyle(QCPGraph::lsNone);

    plot->graph(0)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::green, 7));
    plot->graph(1)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, Qt::red, 5));

    plot->replot();

    rect = new QCPItemRect(plot);
    rect->topLeft->setCoords(xMin, yMax);
    rect->bottomRight->setCoords(xMax, yMin);

    QLabel *fileLbl = new QLabel("Selected file: ");
    fileLbl->setWordWrap(true);

    QGridLayout *layout = new QGridLayout();

    layout->addWidget(plot, 0, 0, 1, 5);
    layout->addWidget(updBtn, 1, 3);
    layout->addWidget(updPolyBtn, 1, 4);
    layout->addWidget(fileBtn, 2, 4);
    layout->addWidget(fileLbl, 1, 0, 1, 3);

    centralWidget()->setLayout(layout);

    connect(updBtn, &QPushButton::clicked, this, [=](){
        type = ClippingType::SEGMENTS;
        updateData();
    });
    connect(updPolyBtn, &QPushButton::clicked, this, [=](){
        type = ClippingType::POLYGON;
        updateData();
    });
    connect(fileBtn, &QPushButton::clicked, this, [=](){
        filePath = QFileDialog::getOpenFileName(this, "Select Input File", QDir::homePath(), "All Files (*.*);;Text Files (*.txt)");
        file = new QFile(filePath);
        fileLbl->setText("Selected file: " + filePath);
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::updateData()
{
    file->open(QIODevice::ReadOnly | QIODevice::Text);

    for (int i = 0; i < lines.size(); i++)
    {
        delete lines[i];
    }

    for (int i = 0; i < goodLines.size(); i++)
    {
        delete goodLines[i];
    }

    lines.clear();
    goodLines.clear();
    v.clear();

    rect->topLeft->setCoords(0, 0);
    rect->bottomRight->setCoords(0, 0);

    plot->graph(0)->data()->clear();
    plot->graph(1)->data()->clear();

    QTextStream input(file);
    int n;

    switch(type)
    {
    case ClippingType::POLYGON:
    {
        if (file->isOpen())
        {
            n = input.readLine().toInt();

            QStringList str;
            double x;
            double y;
            double prevX;
            double prevY;

            str = input.readLine().split(" ");

            if (str.size() != 2)
            {
                file->close();
                return;
            }

            prevX = str[0].toDouble();
            prevY = str[1].toDouble();

            for (int i = 0; i < n - 1; i++)
            {
                str = input.readLine().split(" ");

                if (str.size() != 2)
                {
                    file->close();
                    return;
                }

                x = str[0].toDouble();
                y = str[1].toDouble();

                v.push_back(std::make_pair(QPointF(prevX, prevY), QPointF(x, y)));

                prevX = x;
                prevY = y;
            }

            v.push_back(std::make_pair(QPointF(prevX, prevY), v[0].first));

            str = input.readLine().split(" ");

            if (str.size() != 4)
            {
                file->close();
                return;
            }

            xMin = str[0].toDouble();
            yMin = str[1].toDouble();
            xMax = str[2].toDouble();
            yMax = str[3].toDouble();

            rect->topLeft->setCoords(xMin, yMax);
            rect->bottomRight->setCoords(xMax, yMin);
            rect->setPen(QPen(Qt::black, 3));
        }

        break;
    }
    case ClippingType::SEGMENTS:
    {
        if (file->isOpen())
        {
            n = input.readLine().toInt();
            QStringList str;

            for (int i = 0; i < n; i++)
            {
                str = input.readLine().split(" ");

                if (str.size() != 4)
                {
                    file->close();
                    return;
                }

                double x1 = str[0].toDouble();
                double y1 = str[1].toDouble();
                double x2 = str[2].toDouble();
                double y2 = str[3].toDouble();

                v.push_back(std::make_pair(QPointF(x1, y1), QPointF(x2, y2)));
            }

            str = input.readLine().split(" ");

            if (str.size() != 4)
            {
                file->close();
                return;
            }

            xMin = str[0].toDouble();
            yMin = str[1].toDouble();
            xMax = str[2].toDouble();
            yMax = str[3].toDouble();

            rect->topLeft->setCoords(xMin, yMax);
            rect->bottomRight->setCoords(xMax, yMin);
            rect->setPen(QPen(Qt::black, 3));
        }

        break;
    }
    default:
        break;
    }

    file->close();

    for (int i = 0; i < v.size(); i++)
    {
        if (v[i].first != v[i].second)
        {
            lines.push_back(new QCPItemLine(plot));

            lines.last()->setPen(QPen(Qt::red, 2));
            lines.last()->start->setCoords(v[i].first);
            lines.last()->end->setCoords(v[i].second);

            cutLine(v[i].first, v[i].second, goodLines);
        }
        else
        {
            if (getCode(v[i].first) == 0)
            {
                plot->graph(0)->addData(v[i].first.x(), v[i].first.y());
            }
            else
            {
                plot->graph(1)->addData(v[i].first.x(), v[i].first.y());
            }
        }
    }

    plot->replot();

}

void MainWindow::cutLine(QPointF A, QPointF B, QVector<QCPItemLine*>& goodLines)
{
    if((getCode(A) & getCode(B)) != 0)
    {
        return;
    }

    if(getCode(A) == 0 && getCode(B) == 0)
    {
        goodLines.push_back(new QCPItemLine(plot));

        goodLines.last()->setPen(QPen(Qt::green, 3));
        goodLines.last()->start->setCoords(A);
        goodLines.last()->end->setCoords(B);

        return;
    }

    if (QLineF(A, B).length() <= qPow(10, -3))
    {
        goodLines.push_back(new QCPItemLine(plot));

        goodLines.last()->setPen(QPen(Qt::green, 3));
        goodLines.last()->start->setCoords(A);
        goodLines.last()->end->setCoords(B);

        return;
    }

    cutLine(A, QPointF((A.x() + B.x()) / 2, (A.y() + B.y()) / 2), goodLines);
    cutLine(QPointF((A.x() + B.x()) / 2, (A.y() + B.y()) / 2), B, goodLines);

    return;
}

int MainWindow::getCode(QPointF point)
{
    int code = 0;

    if (point.x() > xMax)
    {
        code |= 1;
    }
    else if (point.x() < xMin)
    {
        code |= 2;
    }
    if (point.y() > yMax)
    {
        code |= 4;
    }
    else if (point.y() < yMin)
    {
        code |= 8;
    }

    return code;
}
