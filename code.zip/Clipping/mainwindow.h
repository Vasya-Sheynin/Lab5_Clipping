
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtWidgets>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow

{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    enum ClippingType { NONE = 0, SEGMENTS, POLYGON };
    Ui::MainWindow *ui;
    QFile *file;
    QString filePath;
    QVector<std::pair<QPointF, QPointF>> v;
    QVector<QCPItemLine*> lines;
    QVector<QCPItemLine*> goodLines;
    QCustomPlot *plot;
    QPushButton *updBtn;
    QPushButton *updPolyBtn;
    QPushButton *fileBtn;
    QCPItemRect *rect;
    ClippingType type;
    double xMin = 0;
    double xMax = 0;
    double yMin = 0;
    double yMax = 0;

    void updateData();
    void cutLine(QPointF A, QPointF B, QVector<QCPItemLine*>& goodLines);
    int getCode(QPointF point);
};

#endif // MAINWINDOW_H
